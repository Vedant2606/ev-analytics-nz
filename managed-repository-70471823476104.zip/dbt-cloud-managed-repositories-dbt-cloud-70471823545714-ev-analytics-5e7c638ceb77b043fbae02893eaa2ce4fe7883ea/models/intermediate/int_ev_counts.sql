with vehicles as (

    select * from {{ ref('stg_vehicles') }}

),

ev_only as (

    -- Filter to electric vehicles only
    select
        vehicle_id,
        make,
        model,
        registration_year,
        registration_month,
        territorial_authority,
        vehicle_type,
        vehicle_usage

    from vehicles
    where motive_power = 'ELECTRIC'
        and registration_year is not null
        and territorial_authority is not null

),

ev_counts as (

    select
        registration_year,
        territorial_authority,
        COUNT(*)                as total_evs_registered,

        -- Running cumulative total per region per year
        SUM(COUNT(*)) OVER (
            PARTITION BY territorial_authority
            ORDER BY registration_year
        )                       as cumulative_evs

    from ev_only
    group by
        registration_year,
        territorial_authority

)

select * from ev_counts
order by territorial_authority, registration_year