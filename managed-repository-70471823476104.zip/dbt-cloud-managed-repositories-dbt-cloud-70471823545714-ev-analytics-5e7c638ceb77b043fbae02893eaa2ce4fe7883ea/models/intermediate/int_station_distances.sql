with stations as (

    select * from {{ ref('stg_stations') }}

),

-- Calculate distance between every pair of stations
-- using the Haversine formula
station_pairs as (

    select
        a.station_id                                as station_a_id,
        a.station_name                              as station_a_name,
        a.operator                                  as station_a_operator,
        a.latitude                                  as station_a_lat,
        a.longitude                                 as station_a_lon,

        b.station_id                                as station_b_id,
        b.station_name                              as station_b_name,
        b.latitude                                  as station_b_lat,
        b.longitude                                 as station_b_lon,

        -- Haversine formula to calculate distance in kilometres
        2 * 6371 * ASIN(
            SQRT(
                POWER(SIN(RADIANS(b.latitude  - a.latitude)  / 2), 2) +
                COS(RADIANS(a.latitude)) *
                COS(RADIANS(b.latitude)) *
                POWER(SIN(RADIANS(b.longitude - a.longitude) / 2), 2)
            )
        )                                           as distance_km

    from stations a
    join stations b
        on a.station_id < b.station_id  -- avoid duplicate pairs

),

-- Find the nearest station for each station
nearest_station as (

    select
        station_a_id                                as station_id,
        station_a_name                              as station_name,
        station_a_operator                          as operator,
        station_a_lat                               as latitude,
        station_a_lon                               as longitude,
        MIN(distance_km)                            as nearest_station_km,

        -- Flag stations that are far from any other station
        CASE
            WHEN MIN(distance_km) > 100
                THEN 'Isolated — over 100km gap'
            WHEN MIN(distance_km) > 50
                THEN 'Remote — 50 to 100km gap'
            ELSE 'Well connected'
        END                                         as coverage_status

    from station_pairs
    group by
        station_a_id,
        station_a_name,
        station_a_operator,
        station_a_lat,
        station_a_lon

)

select * from nearest_station
order by nearest_station_km desc