with source as (

    select * from {{ source('raw', 'RAW_VEHICLES') }}

),

staged as (

    select
        -- IDs
        OBJECTID                                    as vehicle_id,

        -- Vehicle details
        MAKE                                        as make,
        MODEL                                       as model,
        SUBMODEL                                    as submodel,
        VEHICLE_TYPE                                as vehicle_type,
        VEHICLE_USAGE                               as vehicle_usage,
        BODY_TYPE                                   as body_type,
        BASIC_COLOUR                                as colour,

        -- Powertrain
        MOTIVE_POWER                                as motive_power,
        ALTERNATIVE_MOTIVE_POWER                    as alternative_motive_power,
        TRANSMISSION_TYPE                           as transmission_type,
        CC_RATING                                   as cc_rating,
        POWER_RATING                                as power_rating,

        -- Registration info
        FIRST_NZ_REGISTRATION_YEAR::INT             as registration_year,
        FIRST_NZ_REGISTRATION_MONTH::INT            as registration_month,
        VEHICLE_YEAR::INT                           as vehicle_year,
        IMPORT_STATUS                               as import_status,
        ORIGINAL_COUNTRY                            as original_country,

        -- Location
        TLA                                         as territorial_authority,

        -- Emissions
        SYNTHETIC_GREENHOUSE_GAS                    as greenhouse_gas,
        FC_COMBINED::FLOAT                          as fuel_consumption_combined,
        FC_URBAN::FLOAT                             as fuel_consumption_urban,
        FC_EXTRA_URBAN::FLOAT                       as fuel_consumption_extra_urban,

        -- EV type classification
        CASE
            WHEN MOTIVE_POWER = 'ELECTRIC'                      THEN 'BEV'
            WHEN MOTIVE_POWER = 'ELECTRIC [PETROL EXTENDED]'    THEN 'EREV'
            WHEN MOTIVE_POWER = 'ELECTRIC FUEL CELL HYDROGEN'   THEN 'FCEV'
            WHEN MOTIVE_POWER = 'PLUGIN PETROL HYBRID'          THEN 'PHEV'
            ELSE 'OTHER'
        END                                         as ev_type,

        -- Is this an EV flag
        CASE
            WHEN MOTIVE_POWER IN (
                'ELECTRIC',
                'ELECTRIC [PETROL EXTENDED]',
                'ELECTRIC FUEL CELL HYDROGEN',
                'ELECTRIC FUEL CELL OTHER',
                'PLUGIN PETROL HYBRID'
            ) THEN TRUE
            ELSE FALSE
        END                                         as is_ev

    from source

)

select * from staged
