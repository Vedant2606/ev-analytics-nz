with source as (

    select * from {{ source('raw', 'RAW_STATIONS') }}

),

staged as (

    select
        -- IDs
        RAW_DATA:OBJECTID::VARCHAR                  as station_id,
        RAW_DATA:GlobalID::VARCHAR                  as global_id,

        -- Station details
        RAW_DATA:NAME::VARCHAR                      as station_name,
        RAW_DATA:OPERATOR::VARCHAR                  as operator,
        RAW_DATA:OWNER::VARCHAR                     as owner,
        RAW_DATA:ADDRESS::VARCHAR                   as address,

        -- Location (longitude fixed for bp charge Wairakei bad coordinate)
        RAW_DATA:latitude::FLOAT                    as latitude,

        CASE
            WHEN RAW_DATA:longitude::FLOAT < 100
            THEN RAW_DATA:longitude::FLOAT + 100
            ELSE RAW_DATA:longitude::FLOAT
        END                                         as longitude,

        -- Charging details
        RAW_DATA:currentType::VARCHAR               as current_type,
        RAW_DATA:numberOfConnectors::INT            as number_of_connectors,
        RAW_DATA:connectorsList::VARCHAR            as connectors_list,
        RAW_DATA:hasChargingCost::VARCHAR           as has_charging_cost,

        -- Availability
        RAW_DATA:is24Hours::VARCHAR                 as is_24_hours,
        RAW_DATA:carParkCount::INT                  as car_park_count,
        RAW_DATA:hasCarparkCost::VARCHAR            as has_carpark_cost,
        RAW_DATA:maxTimeLimit::VARCHAR              as max_time_limit,
        RAW_DATA:hasTouristAttraction::VARCHAR      as has_tourist_attraction,

        -- Dates
        TRY_TO_DATE(
            RAW_DATA:dateFirstOperational::VARCHAR,
            'DD/MM/YYYY'
        )                                           as date_first_operational

    from source

)

select * from staged