with stations as (

    select * from {{ ref('stg_stations') }}

),

distances as (

    select * from {{ ref('int_station_distances') }}

),

ev_counts as (

    select * from {{ ref('int_ev_counts') }}

),

-- Latest cumulative EV count per region
latest_ev_counts as (

    select
        territorial_authority,
        MAX(cumulative_evs)                 as total_evs

    from ev_counts
    group by territorial_authority

),

-- Station summary with distance info
station_summary as (

    select
        s.station_id,
        s.station_name,
        s.operator,
        s.address,
        s.latitude,
        s.longitude,
        s.current_type,
        s.number_of_connectors,
        s.has_charging_cost,
        s.is_24_hours,
        s.date_first_operational,
        d.nearest_station_km,
        d.coverage_status,

        -- Year station opened
        YEAR(s.date_first_operational)      as year_opened

    from stations s
    left join distances d
        on s.station_id = d.station_id

)

select * from station_summary
order by nearest_station_km desc
