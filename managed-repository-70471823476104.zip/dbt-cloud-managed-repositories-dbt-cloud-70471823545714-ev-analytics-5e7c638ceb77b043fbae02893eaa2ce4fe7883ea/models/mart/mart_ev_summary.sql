with ev_counts as (

    select * from {{ ref('int_ev_counts') }}

),

stations as (

    select * from {{ ref('stg_stations') }}

),

-- Total stations per region
stations_by_region as (

    select
        -- Extract region from address as we don't have TLA on stations
        operator,
        COUNT(*)                            as total_stations,
        SUM(number_of_connectors)           as total_connectors,
        MIN(date_first_operational)         as first_station_opened,
        MAX(date_first_operational)         as latest_station_opened

    from stations
    group by operator

),

-- Total EVs per region per year
ev_by_region as (

    select
        territorial_authority,
        registration_year,
        total_evs_registered,
        cumulative_evs

    from ev_counts

),

-- Overall NZ summary by year
nz_yearly_summary as (

    select
        registration_year,
        SUM(total_evs_registered)           as total_evs_registered_nz,
        SUM(cumulative_evs)                 as total_cumulative_evs_nz

    from ev_counts
    group by registration_year

)

select
    e.registration_year,
    e.territorial_authority,
    e.total_evs_registered,
    e.cumulative_evs,
    n.total_evs_registered_nz,
    n.total_cumulative_evs_nz

from ev_by_region e
left join nz_yearly_summary n
    on e.registration_year = n.registration_year

order by e.territorial_authority, e.registration_year
